import React, { useState, useEffect } from 'react'
import { Grid, } from '@material-ui/core';
import Controls from "../../newcomponents/controls/Controls";
import { useForm, Form } from '../../newcomponents/useForm';
import * as employeeService from "../../services/employeeService";
import TextField from '@material-ui/core/TextField';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';

const initialFValues = {
    empid: '',
    fullName: '',
    mockdate: new Date(),
    mocktakenby: '',
    technology: '',
    therotical: '',
    praticle: '',
    overall: '',
    detailedback:'',
   
}

export default function EmployeeForm() {

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "Pleasr provide fullname."
        if ('empid' in fieldValues)
            temp.empid = (/[0-9]+/).test(fieldValues.empid) ? "" : "Employee-id is not valid."
        if ('theortical' in fieldValues)
            temp.theortical = fieldValues.theortical.length < 4 ? "" : "Should have proper rating."
        if ('overall' in fieldValues)
            temp.overall = fieldValues.overall.length != 0 ? "" : "Please select overall rating."
        if ('detailedfeedback' in fieldValues)
            temp.detailedfeedback =  fieldValues.detailedfeedback.length < 300 ? "" : "Please Keep the lenght within 300 Characters"
        
            setErrors({
            ...temp
        })

        if (fieldValues == values)
            return Object.values(temp).every(x => x == "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
    }

    return (
        <Container maxWidth="lg">
        <Card  variant="outlined">
      <CardContent>
        <Form onSubmit={handleSubmit}>
        <Typography variant="h4" align="center" gutterBottom>
         Mock Feedback Form
      </Typography>
            <Grid container justify="center">
                <Grid item xs={5}>
                    
                <Controls.Input
                        name="empid"
                        label="Employee ID"
                        value={values.empid}
                        onChange={handleInputChange}
                        error={errors.empid}
                    /> 
                    
                     <Controls.Input
                        name="fullName"
                        label="Full Name"
                        value={values.fullName || ''}
                        onChange={handleInputChange}
                        error={errors.fullName}
                    /> 
                    <Controls.DatePicker
                        name="mockdate"
                        label="Mock Date"
                        value={values.mockdate}
                        onChange={handleInputChange}
                    />
                    
                    <Controls.Input
                        label="Mock taken By"
                        name="mocktakenby"
                        value={values.mocktakenby}
                        onChange={handleInputChange}
                        error={errors.mocktakenby}
                    />
                    <Controls.Input
                        label="Technology"
                        name="technology"
                        value={values.technology}
                        onChange={handleInputChange}
                        error={errors.technology}
                    />
                    <Controls.Input
                        label="Therotical rating (out of 100)"
                        name="therotical"
                        value={values.therotical}
                        onChange={handleInputChange}
                    />
                    
                     <Controls.Input
                        label="Praticle rating (out of 100)"
                        name="pratical"
                        value={values.pratical}
                        onChange={handleInputChange}
                    />
    
                    <Controls.Select
                        name="overall"
                        label="Overall Rating"
                        value={values.overall}
                        onChange={handleInputChange}
                        options={employeeService.getDepartmentCollection()}
                        error={errors.overall}
                    />
                    <Controls.Input
                        label="Detailed Feedback"
                        name="detailedfeedback"
                        value={values.detailedfeedback}
                        onChange={handleInputChange}
                        error={errors.detailedfeedback}
                        
                    />
                    <div m={1} >
                        <Controls.Button
                            type="submit"
                            text="Submit" />
                        <Controls.Button
                            text="Reset"
                            color="default"
                            onClick={resetForm} />
                       </div>
                </Grid>
            </Grid>
        </Form>
        </CardContent>
        </Card>
        </Container>
    )
}
