import React, { useState, useEffect } from 'react'
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogTitle from '@material-ui/core/DialogTitle';
import Controls from "../../src/components/feedback/newcomponents/controls/Controls";
import { useForm, Form } from "../../src/components/feedback/newcomponents/useForm";
import  * as employeeService from "../../src/components/feedback/services/employeeService";
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { Container, TextField } from '@material-ui/core';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Chip from '@material-ui/core/Chip';
import { makeStyles, useTheme } from '@material-ui/core/styles';




const genderItems = [
    { id: 'male', title: 'Male' },
    { id: 'female', title: 'Female' },
    { id: 'other', title: 'Other' },
]
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const names = [
  'HTML',
  'CSS',
  'BootStrap',
  'JavaScript',
  'ReactJs',
  'Angular',
  'VueJS',
  'React Native',
  
];
const backs = [
    'Core JAVA',
    'J2EE',
    'Express Js',
    'Ruby',
    'Spring Core',
    'PHP',
    '.Net',
    'Python',
    
  ];
function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }
  function getStylesOne(back, backName, theme) {
    return {
      fontWeight:
        backName.indexOf(back) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

const initialFValues = {
    id: '',
    cname:'',
    fullName: '',
    offemail:'',
    email: '',
    contactNumber: '',
    altContactNumber: '',
    yop:'',
    hqualification:'',
    doj:new Date(),
    dob:new Date(),
    exp:'',
    skillsF:'',
    skillsB:'',
    city: '',
    gender: 'male',
    pincode:'',
    state:'',
    paddress:'',
    taddress:'',
}
const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
      maxWidth: 400,
    },
    chips: {
      display: 'flex',
      flexWrap: 'wrap',
    },
    chip: {
      margin: 2,
    },
    noLabel: {
      marginTop: theme.spacing(3),
    },
    container: {
        display: 'flex',
        flexWrap: 'wrap',
      },
      formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
      },
  }));
  
export default function UserEmployeeDetails() {
    const classes = useStyles();
    const theme = useTheme();
    const [personName, setPersonName] = React.useState([]);
    const [backName, setBackName] = React.useState([]);
    const [open, setOpen] = React.useState(false);
    const [age, setAge] = React.useState('');
  
    const handleChange1 = (event) => {
      setAge(Number(event.target.value) || '');
    };
  
    const handleClickOpen = () => {
      setOpen(true);
    };
  
    const handleClose = () => {
      setOpen(false);
    };
  
    const handleChange = (event) => {
      setPersonName(event.target.value);
    };
    const handleChangeOne = (event) => {
        setBackName(event.target.value);
      };
  
    const handleChangeMultiple = (event) => {
      const { options } = event.target;
      const value = [];
      for (let i = 0, l = options.length; i < l; i += 1) {
        if (options[i].selected) {
          value.push(options[i].value);
        }
      }
      setPersonName(value);
    };

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "This field is required."
            if ('hqualification' in fieldValues)
            temp.hqualification = fieldValues.hqualification ? "" : "This field is required."
            if ('skillsF' in fieldValues)
            temp.skillsF = fieldValues.skillsF ? "" : "This field is required."
            if ('skillsB' in fieldValues)
            temp.skillsB = fieldValues.skillsB ? "" : "This field is required."
            if ('yop' in fieldValues)
            temp.yop = fieldValues.yop ? "" : "This field is required."
            if ('dob' in fieldValues)
            temp.dob = fieldValues.dob ? "" : "This field is required."
        if ('email' in fieldValues)
            temp.email = (/$^|.+@.+..+/).test(fieldValues.email) ? "" : "Email is not valid."
            else temp.email = fieldValues.email ? "" : "Email is required"
        if('contactNumber' in fieldValues)
         temp.contactNumber = (/^[0]?[789]\d{9}$/).test(fieldValues.contactNumber) ? "" : "This field is required  or Invalid contact number."
            if ('pincode' in fieldValues)
            temp. pincode = fieldValues. pincode.length > 6 ? "" : "Minimum 6 numbers required."
            if ('paddress' in fieldValues)
            temp.paddress = fieldValues.paddress ?  "" : "Address is required."
        if ('id' in fieldValues)
            temp.id = (/^[a-zA-Z][a-zA-Z0-9_\-]{0,7}[a-zA-Z0-9]$/).test(fieldValues.id)? "" : "This field is required or Invalid Id."
        setErrors({
            ...temp
        })

        if (fieldValues === values)
            return Object.values(temp).every(x => x === "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
    }

    return (
        <Container maxWidth="md">
        <Card>
            <CardContent>
        
        <Form onSubmit={handleSubmit}>
            <h1>Enter Employee Details</h1>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={6}>
                <Controls.Input
                        name="id"
                        label="Employee ID"
                        value={values.id}
                        onChange={handleInputChange}
                        error={errors.id}
                    />
                    <Controls.Input
                        label="Contact Number"
                        name="contactNumber"
                        defaultValue="Default Value"
                        value={values.contactNumber}
                        onChange={handleInputChange}
                        error={errors.contactNumber}
                    />
                    <Controls.Input
                        label="Official Email"
                        name="email"
                        value={values.email}
                        onChange={handleInputChange}
                        error={errors.email}
                    />
                     <Controls.RadioGroup
                        name="gender"
                        label="Gender"
                        value={values.gender}
                        onChange={handleInputChange}
                        items={genderItems}
                    />
                     
                     
                         <Controls.Input
                        label="Highest Qualification"
                        name="hqualification"
                        value={values.hqualification}
                        onChange={handleInputChange}
                        error={errors.hqualification}
                    />
                    
                <Controls.Input
                        label="Exprience"
                        name="exp"
                        type="Number"
                        value={values.exp}
                        onChange={handleInputChange}
                        error={errors.exp}
                    />
                     {/* <Controls.Input
                        label="Skills On FrontEnd Technology"
                        name="skillsF"
                        value={values.skillsF}
                        onChange={handleInputChange}
                        error={errors.skillsF}
                    />
                     */}
                      <FormControl className={classes.formControl}>
        <InputLabel id="demo-mutiple-chip-label">Skills on Front-End Technology</InputLabel>
        <Select
          labelId="demo-mutiple-chip-label"
          id="demo-mutiple-chip"
          multiple
          variant="outlined"
          value={personName}
          onChange={handleChange}
          input={<Input id="select-multiple-chip" />}
          renderValue={(selected) => (
            <div className={classes.chips}>
              {selected.map((value) => (
                <Chip key={value} label={value} className={classes.chip} />
              ))}
            </div>
          )}
          MenuProps={MenuProps}
        >
          {names.map((name) => (
            <MenuItem key={name} value={name} style={getStyles(name, personName, theme)}>
              {name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
       {/* <Controls.Input
       id="outlined-textarea"
          label="Multiline Placeholder"
          placeholder="Placeholder"
          multiline
          variant="outlined"/> */}


                    {/* //     label="Permanent Address"
                    //     name="paddress"
                    //     value={values.paddress}
                    //     onChange={handleInputChange}
                    //     error={errors.paddress}
    // /> */}
                     <TextField
          id="outlined-textarea"
          label="Permanent Address"
          name="paddress"
              value={values.paddress}
              onChange={handleInputChange}
              error={errors.paddress}
          multiline
          variant="outlined"
        />
                     <Controls.Input
                        label="City"
                        name="city"
                        value={values.city}
                        onChange={handleInputChange}
                    />   
                     
                     <Controls.Input
                        label="Pincode"
                        name="pincode"
                        value={values.pincode}
                        onChange={handleInputChange}
                        error={errors.pincode}
                    />
                {/* <form>

                    </form> */}
                </Grid>
                
                <Grid item xs={6}>
                <Controls.Input
                        name="fullName"
                        label="Full Name"
                        value={values.fullName}
                        onChange={handleInputChange}
                        error={errors.fullName}
                    />
                     <Controls.Input
                        label="Alternate Contact Number"
                        name="altContactNumber"
                        value={values.mobile}
                        onChange={handleInputChange}
                        error={errors.mobile}
                    />
                    <Controls.Input
                        label="Personal Email"
                        name="offemail"
                        value={values.offemail}
                        onChange={handleInputChange}
                        error={errors.offemail}
                    />

                    <Controls.DatePicker
                        name="dob"
                        label="Date Of Birth"
                        value={values.dob}
                        onChange={handleInputChange}
                        error={errors.dob}
                    />
                    
                    <Controls.Input
                        label="Year Of Passout"
                        name="yop"
                        value={values.yop}
                        onChange={handleInputChange}
                        error={errors.yop}/>
                        {/* <Controls.Input
                        label="Company Name"
                        name="exp"
                        type="Number"
                        value={values.cname}
                        onChange={handleInputChange}
                        error={errors.cname}
                    /> */}
                     <Button onClick={handleClickOpen}>Company Name</Button>
      <Dialog disableBackdropClick disableEscapeKeyDown open={open} onClose={handleClose}>
        <DialogTitle>Fill the form</DialogTitle>
        <DialogContent>
          <form className={classes.container}>
            <FormControl className={classes.formControl}>
              <InputLabel htmlFor="demo-dialog-native">Age</InputLabel>
              <Select
                native
                value={age}
                onChange={handleChange1}
                input={<Input id="demo-dialog-native" />}
              >
                <option aria-label="None" value="" />
                <option value={10}>Ten</option>
                <option value={20}>Twenty</option>
                <option value={30}>Thirty</option>
              </Select>
            </FormControl>
            <FormControl className={classes.formControl}>
              <InputLabel id="demo-dialog-select-label">Age</InputLabel>
              <Select
                labelId="demo-dialog-select-label"
                id="demo-dialog-select"
                value={age}
                onChange={handleChange1}
                input={<Input />}
              >
                <MenuItem value="">
                  <em>None</em>
                </MenuItem>
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
          </form>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary">
            Cancel
          </Button>
          <Button onClick={handleClose} color="primary">
            Ok
          </Button>
        </DialogActions>
      </Dialog>

                     {/* <Controls.Input
                        label="Skills On BackEnd Technology"
                        name="skillsB"
                        value={values.skillsB}
                        onChange={handleInputChange}
                        error={errors.skillsB}
                    /> */}
                      <FormControl className={classes.formControl}>
        <InputLabel id="demo-mutiple-chip-label">Skills on Back-End Technology</InputLabel>
        <Select
          labelId="demo-mutiple-chip-label"
          id="demo-mutiple-chip"
          multiple
          variant="outlined"
          value={backName}
          onChange={handleChangeOne}
          input={<Input id="select-multiple-chip" />}
          renderValue={(selected) => (
            <div className={classes.chips}>
              {selected.map((value) => (
                <Chip key={value} label={value} className={classes.chip} />
              ))}
            </div>
          )}
          MenuProps={MenuProps}
        >
          {backs.map((back) => (
            <MenuItem key={back} value={back} style={getStylesOne(back, backName, theme)}>
              {back}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
                    <Controls.DatePicker
                        name="dob"
                        label="Date Of Joining"
                        value={values.doj}
                        onChange={handleInputChange}
                        error={errors.doj}
                    />
                     
                    
                    {/* <Controls.Input
                        label="Temporary Address"
                        name="taddress"
                        value={values.taddress}
                        onChange={handleInputChange}
                    />
                     */}
                          <TextField
          id="outlined-textarea"
          label="Temporary Address"
          name="taddress"
          value={values.taddress}
          onChange={handleInputChange}
          multiline
          variant="outlined"
        />
                   
                    
                    
                    <Controls.Input
                        label="State"
                        name="state"
                        value={values.state}
                        onChange={handleInputChange}
                    />
                   
                    {/* <div style={{display: 'flex', justifyContent : "flex-end"}}> 
                    <button  style={{border:"solid" , height:" 50px",width : "80px", borderRadius:" 12px", padding: "5px", fontSize:"18px"}}>Submit</button>
                    <button type="reset" onClick={resetForm}  style={{border:"solid" , height:" 50px",width : "80px", borderRadius:" 12px", padding: "5px", fontSize:"18px"}}>Reset</button>

                    </div> */}
                      <div m={1} >
                        <Controls.Button
                            type="submit"
                            text="Submit" />
                        <Controls.Button
                            text="Reset"
                            color="default"
                            onClick={resetForm} />
                       </div>

                </Grid>
            </Grid>
        </Form>
        </CardContent>
        </Card>
        </Container>
        
    )
}
