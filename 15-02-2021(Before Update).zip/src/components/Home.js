import React, { Component } from 'react'
import PrimarySearchAppBar from './Navbar'

export default class WelcomePage extends Component {
    render() {
        return (
            <div className="welcomePage">
                <PrimarySearchAppBar/>
                 <img src="https://www.testyantra.com/sites/default/files/tylog1.png" alt="" className="imageposition"></img>
            {/* <h4>Employee Monitoring Software to enhance your employee productivity</h4>
            <p>Meet the WorkComposer Team
Our Goal: To help individuals and organizations be more productive. To help people stop wasting their lives on distractions and finish what is important to them instead. We're obsessed about time here at WorkComposer. We all have the same twenty-four hours starting point every single day. It doesn't matter if you're rich or poor. Now whoever utilizes their time the best are the ones who progress faster.</p> */}
            </div>
        )
    }
}
