import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import  FormPropsTextFields from './Login&Register'
import PrimarySearchAppBar from "./Navbar"
import Home from "./Home"
import AdminLogin from "./AdminLogin";
import InnerAdminDetails from "./InnerAdminDetails";
import InnerUserDetails from "./InnerUserDetails";
import EmployeeForm from "./feedback/pages/Employees/EmployeeForm";

export default function BasicExample() {
  return (
    <Router>
      <div>

            <Link to="/"></Link>

            <Link to="/about"></Link>

            <Link to="/dashboard"></Link>

        <Switch>
          <Route exact path="/">
            <Home/>
          </Route>
          <Route path="/about">
          <PrimarySearchAppBar/>
          </Route>
          <Route path="/dashboard">
          <FormPropsTextFields/>
          </Route>
          <Route path="/adminlogin">
          <AdminLogin/>
          </Route>
          <Route path="/active" component={InnerAdminDetails}>
          </Route>
          <Route path="/useractive" component={InnerUserDetails}>
          </Route>
          <Route path="/employeeForm" component={InnerAdminDetails}>
          </Route>

      <Route path="/Home" component={Home}>
      </Route>        
        </Switch>
      </div>
    </Router>
  );
}

