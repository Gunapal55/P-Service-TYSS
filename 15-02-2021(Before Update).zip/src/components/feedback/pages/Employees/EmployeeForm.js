// import React, { useState, useEffect } from 'react'
// import { Grid, } from '@material-ui/core';
// import Controls from "../../newcomponents/controls/Controls";
// import { useForm, Form } from '../../newcomponents/useForm';
// import * as employeeService from "../../services/employeeService";
// import TextField from '@material-ui/core/TextField';



// const initialFValues = {
//     empid: '',
//     fullName: '',
//     mockdate: new Date(),
//     mocktakenby: '',
//     technology: '',
//     therotical: '',
//     praticle: '',
//     overall: '',
//     detailedfeedback:''
   
// }

// export default function EmployeeForm() {

//     const validate = (fieldValues = values) => {
//         let temp = { ...errors }
//         if ('fullName' in fieldValues)
//             temp.fullName = fieldValues.fullName ? "" : "Pleasr provide fullname."
//         if ('empid' in fieldValues)
//             temp.empid = (/[0-9]+/).test(fieldValues.empid) ? "" : "Employee-id is not valid."
//         if ('therotical' in fieldValues)
//             temp.therotical = fieldValues.therotical.length < 4 ? "" : "Should have proper rating."
//         if ('overall' in fieldValues)
//             temp.overall = fieldValues.overall.length !== 0 ? "" : "Please select overall rating."
//         setErrors({
//             ...temp
//         })

//         if (fieldValues === values)
//             return Object.values(temp).every(x => x == "")
//     }

//     const {
//         values,
//         setValues,
//         errors,
//         setErrors,
//         handleInputChange,
//         resetForm
//     } = useForm(initialFValues, true, validate);

//     const handleSubmit = e => {
//         e.preventDefault()
//         if (validate()){
//             employeeService.insertEmployee(values)
//             resetForm()
//         }
//     }

//     return (<div>
//         <Form onSubmit={handleSubmit}>
//             <Grid container justify="center">
//                 <Grid item xs={6}>
//                     <h1>Enter Mock Details</h1>


//                 <Controls.Input
//                         name="empid"
//                         label="Employee ID"
//                         value={values.empid}
//                         onChange={handleInputChange}
//                         error={errors.empid}
//                     /> 
                    
//                      <Controls.Input
//                         name="fullName"
//                         label="Full Name"
//                         value={values.fullName || ''}
//                         onChange={handleInputChange}
//                         error={errors.fullName}
//                     /> 
//                     <form>
//                     <TextField
//                     id="date"
//                     label="Mock Taken Date"
//                     type="date"
//                     defaultValue=""
//                     InputLabelProps={{
//                     shrink: true,
//                      }}
//                      />
//                     </form>
                    
//                     <Controls.Input
//                         label="Mock taken By"
//                         name="mocktakenby"
//                         value={values.mocktakenby}
//                         onChange={handleInputChange}
//                         error={errors.mocktakenby}
//                     />
//                     <Controls.Input
//                         label="Technology"
//                         name="technology"
//                         value={values.technology}
//                         onChange={handleInputChange}
//                         error={errors.technology}
//                     />
//                     <Controls.Input
//                         label="Therotical rating (out of 100)"
//                         name="therotical"
//                         value={values.therotical}
//                         onChange={handleInputChange}
//                     />
                    
//                      <Controls.Input
//                         label="Praticle rating (out of 100)"
//                         name="pratical"
//                         value={values.pratical}
//                         onChange={handleInputChange}
//                     />
    
//                     <Controls.Select
//                         name="overall"
//                         label="Overall Rating"
//                         value={values.overall}
//                         onChange={handleInputChange}
//                         options={employeeService.getDepartmentCollection()}
//                         error={errors.overall}
//                     />
//                     <Controls.Input
//                         label="Detailed Feedback"
//                         name="detailedfeedback"
//                         value={values.detailedfeedback}
//                         onChange={handleInputChange}
//                         error={errors.detailedfeedback}
//                     />
//                                        <div> 
//                     <button  style={{border:"solid" ,backgroundColor:" rgba(19,38,79,1)",color:"white", borderRadius:" 12px", padding: "10px"}}>Submit</button>
//                     <button type="reset" onClick={resetForm}  style={{border:"solid" ,backgroundColor:" rgba(19,38,79,1)",color:"white", borderRadius:" 12px", padding: "6px"}}>Reset</button>
//                     </div>
//                 </Grid>
//             </Grid>
//         </Form>
//         </div>
//     )
// }


import React, { useState, useEffect } from 'react'
import { Grid, } from '@material-ui/core';
import Controls from "../../newcomponents/controls/Controls";
import { useForm, Form } from '../../newcomponents/useForm';
import * as employeeService from "../../services/employeeService";


const initialFValues = {
    empid: '',
    fullName: '',
    mockdate: new Date(),
    mocktakenby: '',
    technology: '',
    therotical: '',
    praticle: '',
    overall: '',
    detailedfeedback:'',
   
}

export default function EmployeeForm() {

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "Pleasr provide fullname."
        if ('empid' in fieldValues)
            temp.empid = (/[0-9]+/).test(fieldValues.empid) ? "" : "Employee-id is not valid."
        if ('theortical' in fieldValues)
            temp.theortical = fieldValues.theortical.length < 4 ? "" : "Should have proper rating."
        if ('overall' in fieldValues)
            temp.overall = fieldValues.overall.length != 0 ? "" : "Please select overall rating."
            if ('detailedfeedback' in fieldValues)
            temp.detailedfeedback = fieldValues.detailedfeedback.length <300 ? "" : "Please keep character count below 300."
        setErrors({
            ...temp
        })

        if (fieldValues == values)
            return Object.values(temp).every(x => x == "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
    }

    return (
        <Form onSubmit={handleSubmit}>
            <Grid container justify="center">
                <Grid item xs={6}>
                    
                <Controls.Input
                        name="empid"
                        label="Employee ID"
                        value={values.empid}
                        onChange={handleInputChange}
                        error={errors.empid}
                    /> 
                    
                     <Controls.Input
                        name="fullName"
                        label="Full Name"
                        value={values.fullName || ''}
                        onChange={handleInputChange}
                        error={errors.fullName}
                    /> 
                    <Controls.DatePicker
                        name="mockdate"
                        label="Mock Date"
                        value={values.mockdate}
                        onChange={handleInputChange}
                    />
                    
                    <Controls.Input
                        label="Mock taken By"
                        name="mocktakenby"
                        value={values.mocktakenby}
                        onChange={handleInputChange}
                        error={errors.mocktakenby}
                    />
                    <Controls.Input
                        label="Technology"
                        name="technology"
                        value={values.technology}
                        onChange={handleInputChange}
                        error={errors.technology}
                    />
                    <Controls.Input
                        label="Therotical rating (out of 100)"
                        name="therotical"
                        value={values.therotical}
                        onChange={handleInputChange}
                    />
                    
                     <Controls.Input
                        label="Praticle rating (out of 100)"
                        name="pratical"
                        value={values.pratical}
                        onChange={handleInputChange}
                    />
    
                    <Controls.Select
                        name="overall"
                        label="Overall Rating"
                        value={values.overall}
                        onChange={handleInputChange}
                        options={employeeService.getDepartmentCollection()}
                        error={errors.overall}
                    />
                    <Controls.Input
                        label="Detailed Feedback"
                        name="detailedfeedback"
                        value={values.detailedfeedback}
                        onChange={handleInputChange}
                        error={errors.detailedfeedback}
                    />
                    <div m={1} >
                        <Controls.Button
                            type="submit"
                            text="Submit" />
                        <Controls.Button
                            text="Reset"
                            color="default"
                            onClick={resetForm} />
                       </div>
                </Grid>
            </Grid>
        </Form>
    )
}


// const validate = values => {
//     const errors = {}
//     const requiredFields = [ 'firstName', 'lastName', 'email', 'favoriteColor', 'notes' ]
//     requiredFields.forEach(field => {
//       if (!values[ field ]) {
//         errors[ field ] = 'Required'
//       }
//     })
//     if (values.email && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
//       errors.email = 'Invalid email address'
//     }
//     return errors
//   }
  
//   const renderTextField = ({ input, label, meta: { touched, error }, ...custom }) => (
//     <TextField hintText={label}
//       floatingLabelText={label}
//       errorText={touched && error}
//       {...input}
//       {...custom}
//     />
//   )
  
//   const renderCheckbox = ({ input, label }) => (
//     <Checkbox label={label}
//       checked={input.value ? true : false}
//       onCheck={input.onChange}/>
//   )
  
//   const renderRadioGroup = ({ input, ...rest }) => (
//     <RadioButtonGroup {...input} {...rest}
//       valueSelected={input.value}
//       onChange={(event, value) => input.onChange(value)}/>
//   )
  
//   const renderSelectField = ({ input, label, meta: { touched, error }, children, ...custom }) => (
//     <SelectField
//       floatingLabelText={label}
//       errorText={touched && error}
//       {...input}
//       onChange={(event, index, value) => input.onChange(value)}
//       children={children}
//       {...custom}/>
//   )
  
//   const MaterialUiForm = props => {
//     const { handleSubmit, pristine, reset, submitting } = props
//     return (
//       <form onSubmit={handleSubmit}>
//         <div>
//           <Field name="firstName" component={renderTextField} label="First Name"/>
//         </div>
//         <div>
//           <Field name="lastName" component={renderTextField} label="Last Name"/>
//         </div>
//         <div>
//           <Field name="email" component={renderTextField} label="Email"/>
//         </div>
//         <div>
//           <Field name="sex" component={renderRadioGroup}>
//             <RadioButton value="male" label="male"/>
//             <RadioButton value="female" label="female"/>
//           </Field>
//         </div>
//         <div>
//           <Field name="favoriteColor" component={renderSelectField} label="Favorite Color">
//             <MenuItem value={'ff0000'} primaryText="Red"/>
//             <MenuItem value={'00ff00'} primaryText="Green"/>
//             <MenuItem value={'0000ff'} primaryText="Blue"/>
//           </Field>
//         </div>
//         <div>
        //    <Field name="employed" component={renderCheckbox} label="Employed"/>
//         </div>
//         <div>
//           <Field name="notes" component={renderTextField} label="Notes" multiLine={true} rows={2}/>
//         </div>
//         <div>
//           <button type="submit" disabled={pristine || submitting}>Submit</button>
//           <button type="button" disabled={pristine || submitting} onClick={reset}>Clear Values
//           </button>
//         </div>
//       </form>
//     )
//   }
  
//   export default reduxForm({
//     form: 'MaterialUiForm',  // a unique identifier for this form
//     validate,
//     AsyncValidate
//   })(MaterialUiForm)