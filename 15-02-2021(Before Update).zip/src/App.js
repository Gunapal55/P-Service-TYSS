import logo from './logo.svg';
import './App.css';
import EmployeeForm from './component/pages/Employees/EmployeeForm';
import BasicExample from './components/EmployeeFinalLink';

function App() {
  return (
    <div>
    <BasicExample />
    </div>
  );
}

export default App;
